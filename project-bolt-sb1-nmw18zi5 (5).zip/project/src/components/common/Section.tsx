import React from 'react';

interface SectionProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
}

export function Section({ children, title, subtitle, className = '' }: SectionProps) {
  return (
    <section className={`py-20 bg-[#161658] ${className}`}>
      <div className="container mx-auto px-6">
        {(title || subtitle) && (
          <div className="text-center mb-16">
            {title && <h2 className="text-4xl font-bold mb-4 text-white">{title}</h2>}
            {subtitle && <p className="text-xl text-purple-100">{subtitle}</p>}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}