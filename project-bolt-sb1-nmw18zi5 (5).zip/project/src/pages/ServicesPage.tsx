import React from 'react';
import { servicesData } from '../components/Services/services-data';
import { LiquidBackground } from '../components/LiquidBackground';

export function ServicesPage() {
  return (
    <main className="pt-20">
      <section className="relative min-h-screen py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)] overflow-hidden">
        <LiquidBackground />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
              Our Services
            </h1>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Comprehensive software solutions tailored to your business needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {servicesData.map((service) => (
              <div
                key={service.title}
                id={service.title.toLowerCase().replace(/\s+/g, '-')}
                className="group relative"
              >
                {/* Glassmorphism card with hover effects */}
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
                
                <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 transition-all duration-500 group-hover:translate-y-[-4px]">
                  <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent rounded-xl" />
                  <div className="relative">
                    <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-gradient-to-br from-white/10 to-transparent rounded-lg">
                        <service.Icon className="w-8 h-8 text-blue-400 group-hover:text-blue-200 transition-colors" />
                      </div>
                      <h3 className="text-2xl font-bold text-white group-hover:text-blue-200 transition-colors">
                        {service.title}
                      </h3>
                    </div>
                    
                    <p className="text-gray-300 mb-6">{service.description}</p>
                    
                    <div className="space-y-2">
                      {service.features.map((feature, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-2 text-sm text-gray-400 group-hover:text-gray-300 transition-colors"
                        >
                          <span className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                          {feature}
                        </div>
                      ))}
                    </div>

                    {/* Hover indicator */}
                    <div className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="text-blue-400 flex items-center gap-1">
                        <span className="text-sm">Learn more</span>
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}