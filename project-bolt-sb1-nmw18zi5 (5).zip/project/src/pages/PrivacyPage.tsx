import React from 'react';

export function PrivacyPage() {
  return (
    <main className="pt-20">
      <section className="py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)]">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
            Privacy Policy
          </h1>
          
          <div className="max-w-4xl mx-auto space-y-8 text-gray-300">
            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">Information Collection</h2>
              <p className="mb-4">
                We collect information that you provide directly to us, including:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Contact information (name, email, phone number)</li>
                <li>Business information</li>
                <li>Project requirements and specifications</li>
                <li>Communication records</li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">Data Usage</h2>
              <p className="mb-4">We use your information to:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Provide and improve our services</li>
                <li>Communicate about projects</li>
                <li>Send updates and marketing communications</li>
                <li>Ensure security and prevent fraud</li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">Data Protection</h2>
              <p>
                We implement appropriate technical and organizational measures to protect your personal data against unauthorized access, alteration, disclosure, or destruction.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">Your Rights</h2>
              <p className="mb-4">You have the right to:</p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Access your personal data</li>
                <li>Request data correction or deletion</li>
                <li>Object to data processing</li>
                <li>Data portability</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}