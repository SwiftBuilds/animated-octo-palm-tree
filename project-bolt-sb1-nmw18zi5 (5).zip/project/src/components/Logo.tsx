import React from 'react';
import { Code2 } from 'lucide-react';

export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-700 blur-sm opacity-75" />
        <Code2 className="w-8 h-8 text-white relative z-10" />
      </div>
      <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-white font-display">
        SwiftBuilds
      </span>
    </div>
  );
}