import React from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

function FAQItem({ question, answer, isOpen, onClick }: FAQItemProps) {
  return (
    <div className="border-b border-white/10">
      <button
        className="w-full py-4 flex items-center justify-between text-left"
        onClick={onClick}
      >
        <span className="text-lg font-medium">{question}</span>
        {isOpen ? (
          <ChevronUp className="w-5 h-5 text-purple-400" />
        ) : (
          <ChevronDown className="w-5 h-5 text-purple-400" />
        )}
      </button>
      {isOpen && (
        <div className="pb-4 text-gray-300">
          {answer}
        </div>
      )}
    </div>
  );
}

export function FAQ() {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  const faqs = [
    {
      question: "What technologies do you specialize in?",
      answer: "We specialize in a wide range of modern technologies including React, Angular, Vue.js, Node.js, Python, .NET, AWS, Azure, and more. Our team stays up-to-date with the latest technological advancements to provide cutting-edge solutions."
    },
    {
      question: "How do you ensure project quality and timely delivery?",
      answer: "We follow agile methodologies with regular sprints and quality checks. Our development process includes thorough code reviews, automated testing, and continuous integration/deployment (CI/CD) practices to ensure high-quality deliverables within agreed timelines."
    },
    {
      question: "What is your typical project development process?",
      answer: "Our process typically includes: Initial consultation and requirements gathering, detailed planning and architecture design, agile development phases, regular client updates and feedback sessions, thorough testing, and post-deployment support."
    },
    {
      question: "Do you provide post-development support and maintenance?",
      answer: "Yes, we offer comprehensive post-development support and maintenance packages. This includes bug fixes, security updates, performance optimization, and feature enhancements based on your needs."
    },
    {
      question: "How do you handle project security and confidentiality?",
      answer: "We take security seriously and implement industry-standard security practices. This includes secure development practices, regular security audits, and strict confidentiality agreements. We also ensure compliance with relevant data protection regulations."
    },
    {
      question: "What is your pricing model?",
      answer: "We offer flexible pricing models including fixed-price projects, time and materials, and dedicated team arrangements. The specific model is chosen based on project requirements, scope, and client preferences."
    },
    {
      question: "Can you scale our existing application?",
      answer: "Yes, we specialize in scaling applications. Our team can analyze your current architecture, identify bottlenecks, and implement solutions for improved performance and scalability using cloud services, microservices architecture, and other modern scaling techniques."
    },
    {
      question: "Do you provide UI/UX design services?",
      answer: "Yes, we have a dedicated team of UI/UX designers who create intuitive, user-friendly interfaces. Our design process includes user research, wireframing, prototyping, and iterative refinement based on user feedback."
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-[rgba(20,19,79,255)] to-[#14134f] text-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-300">
            Find answers to common questions about our services and processes
          </p>
        </div>
        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <FAQItem
              key={index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === index}
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}