import { Code2, Smartphone, Globe, Palette, Brain, Cloud, Shield, Database, Bot, Rocket } from 'lucide-react';

export const homeServicesData = [
  {
    title: "Custom Software Development",
    description: "Tailored solutions built with cutting-edge technology to solve your unique business challenges.",
    Icon: Code2,
    features: ["Enterprise Applications", "Custom CRM/ERP", "Legacy System Modernization"],
    gradient: "from-blue-400 to-blue-600"
  },
  {
    title: "Mobile App Development",
    description: "Native and cross-platform mobile applications that deliver exceptional user experiences.",
    Icon: Smartphone,
    features: ["iOS & Android Apps", "React Native", "Flutter Development"],
    gradient: "from-blue-500 to-blue-700"
  },
  {
    title: "Cloud Solutions",
    description: "Scalable cloud infrastructure and migration services for optimal performance.",
    Icon: Cloud,
    features: ["AWS & Azure", "Cloud Migration", "DevOps"],
    gradient: "from-blue-600 to-blue-800"
  },
  {
    title: "AI & Machine Learning",
    description: "Intelligent solutions that leverage advanced AI to drive business growth.",
    Icon: Bot,
    features: ["Predictive Analytics", "Computer Vision", "Natural Language Processing"],
    gradient: "from-blue-700 to-blue-900"
  },
  {
    title: "UI/UX Design",
    description: "Beautiful, intuitive interfaces that enhance user engagement and satisfaction.",
    Icon: Palette,
    features: ["User Research", "Interface Design", "Prototyping"],
    gradient: "from-blue-500 to-blue-700"
  },
  {
    title: "Digital Transformation",
    description: "End-to-end digital solutions to modernize your business operations.",
    Icon: Rocket,
    features: ["Process Automation", "Digital Strategy", "Technology Consulting"],
    gradient: "from-blue-600 to-blue-800"
  }
];