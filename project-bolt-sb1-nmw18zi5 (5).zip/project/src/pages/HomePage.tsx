import React from 'react';
import { Hero } from '../components/Hero';
import { HomeServices } from '../components/HomeServices';
import { FAQ } from '../components/FAQ';
import { Reviews } from '../components/Reviews';

export function HomePage() {
  return (
    <main>
      <Hero />
      <HomeServices />
      <FAQ />
      <Reviews />
    </main>
  );
}