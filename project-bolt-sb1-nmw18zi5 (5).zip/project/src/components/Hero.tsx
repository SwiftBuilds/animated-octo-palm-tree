import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen flex items-center justify-center bg-primary text-white overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary opacity-80" />
        {/* Floating orbs */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full animate-float mix-blend-screen"
            style={{
              width: `${Math.random() * 300 + 50}px`,
              height: `${Math.random() * 300 + 50}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: `radial-gradient(circle at center, rgba(59,130,246,0.3), transparent)`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${Math.random() * 10 + 10}s`,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="font-display text-display-1 font-bold mb-8 leading-tight">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-white via-accent to-blue-200">
              Building Software,
            </span>
            <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-200 via-accent to-white">
              Building Futures
            </span>
          </h1>
          <p className="font-sans text-body-large mb-12 text-blue-100 max-w-2xl mx-auto">
            Transforming ideas into powerful digital solutions with cutting-edge technology
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button
              onClick={() => navigate('/contact')}
              className="group bg-white text-primary px-8 py-4 rounded-lg font-medium transition-all duration-300 hover:bg-opacity-90 flex items-center justify-center gap-2"
            >
              Get Started
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => navigate('/portfolio')}
              className="group px-8 py-4 rounded-lg font-medium border-2 border-white hover:bg-white hover:text-primary transition-all duration-300"
            >
              View Portfolio
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}