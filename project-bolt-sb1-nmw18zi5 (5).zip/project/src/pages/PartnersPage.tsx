import React from 'react';

const partners = [
  {
    name: "TechVeda Solutions",
    description: "Leading provider of enterprise software solutions",
    logo: "https://images.unsplash.com/photo-1560179707-f14e90ef3623?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    type: "Technology Partner"
  },
  {
    name: "CloudTech India",
    description: "Premier cloud infrastructure provider",
    logo: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    type: "Infrastructure Partner"
  },
  {
    name: "Digital Dynamics",
    description: "Digital transformation consultancy",
    logo: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    type: "Strategic Partner"
  },
  {
    name: "InnovateIndia",
    description: "Innovation and research partner",
    logo: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    type: "Research Partner"
  },
  {
    name: "SecureNet Solutions",
    description: "Cybersecurity solutions provider",
    logo: "https://images.unsplash.com/photo-1573164713988-8665fc963095?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    type: "Security Partner"
  },
  {
    name: "DataTech Analytics",
    description: "Data analytics and AI solutions",
    logo: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80",
    type: "Analytics Partner"
  }
];

export function PartnersPage() {
  return (
    <main className="pt-20">
      <section className="py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)]">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
            Our Trusted Partners
          </h1>
          
          <p className="text-xl text-center text-gray-300 mb-12 max-w-3xl mx-auto">
            We collaborate with industry leaders to deliver exceptional solutions and drive innovation
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {partners.map((partner) => (
              <div key={partner.name} className="group relative">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
                
                <div className="relative bg-white/5 backdrop-blur-xl rounded-xl p-8 border border-blue-500/20">
                  <div className="mb-6 overflow-hidden rounded-lg">
                    <img
                      src={partner.logo}
                      alt={partner.name}
                      className="w-full h-48 object-cover transform group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <span className="text-blue-400 text-sm font-medium">{partner.type}</span>
                    <h3 className="text-2xl font-bold text-white">{partner.name}</h3>
                    <p className="text-gray-300">{partner.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}