import React from 'react';

export function BackgroundEffects() {
  return (
    <div className="absolute inset-0">
      {/* Base gradient */}
      <div className="absolute inset-0 bg-[#14134f]" />
      
      {/* Animated waves */}
      <div className="absolute inset-0">
        {[...Array(3)].map((_, i) => (
          <div
            key={`wave-${i}`}
            className="absolute inset-0 animate-wave"
            style={{
              background: `radial-gradient(circle at ${50 + (i * 30)}% ${50 + (i * 20)}%, rgba(59,130,246,0.1), transparent 60%)`,
              animationDelay: `${i * 2}s`,
              transform: `scale(${1 + i * 0.2})`,
            }}
          />
        ))}
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={`particle-${i}`}
            className="absolute rounded-full mix-blend-screen animate-float"
            style={{
              width: `${Math.random() * 8 + 4}px`,
              height: `${Math.random() * 8 + 4}px`,
              background: 'rgba(59,130,246,0.3)',
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDuration: `${Math.random() * 10 + 10}s`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}