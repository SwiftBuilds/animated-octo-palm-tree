import React from 'react';
import { Users, Target, Award, Rocket } from 'lucide-react';
import { values } from './data';

const iconMap = {
  Users,
  Target,
  Award,
  Rocket
};

export function Values() {
  return (
    <div className="mb-20">
      <h2 className="text-3xl font-bold mb-12 text-center">Our Values</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {values.map((value) => {
          const Icon = iconMap[value.icon as keyof typeof iconMap];
          return (
            <div key={value.title} className="group relative">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
              <div className="relative bg-white/5 backdrop-blur-lg rounded-xl p-6 h-full">
                <Icon className="w-12 h-12 text-blue-400 mb-4" />
                <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                <p className="text-gray-300">{value.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}