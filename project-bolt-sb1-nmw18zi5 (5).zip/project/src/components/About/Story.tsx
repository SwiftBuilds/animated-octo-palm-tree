export function Story() {
  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8 mb-20">
      <h2 className="text-3xl font-bold mb-6 text-center">Our Story</h2>
      <div className="max-w-3xl mx-auto text-gray-300 space-y-4">
        <p>
          Founded in 2014, SwiftBuilds began with a vision to revolutionize how businesses leverage technology. What started as a small team of passionate developers in Hyderabad has grown into a global technology solutions provider with a presence across multiple countries.
        </p>
        <p>
          Our journey has been marked by continuous innovation, unwavering commitment to quality, and a deep understanding of evolving business needs. We've successfully delivered over 500 projects across various industries, helping businesses transform their digital presence and operational efficiency.
        </p>
        <p>
          Today, we're proud to be at the forefront of technological innovation, with specialized teams in AI/ML, cloud computing, and digital transformation. Our success is built on the foundation of client trust, technical excellence, and our ability to deliver solutions that drive real business value.
        </p>
      </div>
    </div>
  );
}