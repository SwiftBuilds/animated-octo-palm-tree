import React from 'react';
import { ServiceGrid } from './ServiceGrid';
import { BackgroundEffects } from './BackgroundEffects';

export function Services() {
  return (
    <section className="relative py-20 overflow-hidden">
      <BackgroundEffects />
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-white">
            Our Services
          </h2>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Comprehensive solutions for your digital transformation journey
          </p>
        </div>
        <ServiceGrid />
      </div>
    </section>
  );
}