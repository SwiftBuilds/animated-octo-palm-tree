import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  description: string;
  category: string;
  tech: string[];
  Icon: LucideIcon;
}

export function ProjectCard({ title, description, category, tech, Icon }: ProjectCardProps) {
  return (
    <div className="bg-white rounded-lg p-6 transition-all duration-300 hover:shadow-xl">
      <div className="flex items-center gap-2 mb-4">
        <Icon className="w-6 h-6 text-[#161658]" />
        <span className="text-sm font-medium text-[#161658]">{category}</span>
      </div>
      <h3 className="text-xl font-bold mb-2 text-[#161658]">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <div className="flex flex-wrap gap-2">
        {tech.map((item) => (
          <span
            key={item}
            className="text-xs px-3 py-1 rounded-full bg-[#161658] text-white"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}