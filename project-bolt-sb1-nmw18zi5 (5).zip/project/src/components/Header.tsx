import React from 'react';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'Portfolio', href: '/portfolio' },
    { name: 'About Us', href: '/about' },
    { name: 'Services', href: '/services' },
  ];

  return (
    <header className="fixed w-full bg-gradient-to-r from-primary via-primary to-secondary text-white z-50 backdrop-blur-sm bg-opacity-80">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <RouterLink to="/" className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/50 to-blue-700/50 blur-lg opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-white font-display relative z-10">
              SwiftBuilds
            </span>
          </RouterLink>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <RouterLink
                key={item.name}
                to={item.href}
                className="text-white hover:text-blue-400 transition-colors"
              >
                {item.name}
              </RouterLink>
            ))}
            <RouterLink
              to="/contact"
              className="bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 px-6 py-2 rounded-full font-medium transition-all duration-300 transform hover:scale-105"
            >
              Get Started
            </RouterLink>
          </div>

          {/* Mobile Navigation Button */}
          <div className="md:hidden">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            {navigation.map((item) => (
              <RouterLink
                key={item.name}
                to={item.href}
                className="block py-2 hover:text-blue-400"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </RouterLink>
            ))}
            <RouterLink
              to="/contact"
              className="block w-full bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 px-6 py-2 rounded-full font-medium text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              Get Started
            </RouterLink>
          </div>
        )}
      </nav>
    </header>
  );
}