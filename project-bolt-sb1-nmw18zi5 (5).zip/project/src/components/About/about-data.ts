export const companyStats = [
  { label: 'Years of Experience', value: '10+' },
  { label: 'Projects Delivered', value: '500+' },
  { label: 'Team Members', value: '100+' },
  { label: 'Client Satisfaction', value: '99%' },
  { label: 'Global Clients', value: '200+' },
  { label: 'Industries Served', value: '15+' }
];

export const companyStory = {
  intro: `SwiftBuilds, established in 2014, has emerged as a leading force in the software development industry. What began as a small team of passionate developers in Hyderabad has grown into a global technology solutions provider with a presence across multiple countries.`,
  
  mission: `Our mission is to empower businesses with innovative technology solutions that drive growth and create lasting impact. We believe in pushing the boundaries of what's possible while maintaining the highest standards of quality and reliability.`,
  
  expertise: `With expertise spanning web development, mobile applications, cloud solutions, and emerging technologies like AI and IoT, we've helped hundreds of businesses across various industries achieve their digital transformation goals.`,
  
  culture: `At SwiftBuilds, we foster a culture of innovation, continuous learning, and excellence. Our team of skilled professionals brings together diverse perspectives and expertise to deliver exceptional results for our clients.`,
  
  future: `Looking ahead, we remain committed to staying at the forefront of technological advancement, continuously evolving our capabilities to meet the changing needs of businesses in an increasingly digital world.`
};