import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from './config';

interface ContactFormData {
  name: string;
  email: string;
  message: string;
}

export async function submitContactForm(data: ContactFormData) {
  try {
    const docRef = await addDoc(collection(db, 'contacts'), {
      ...data,
      timestamp: serverTimestamp(),
    });
    return { success: true, id: docRef.id };
  } catch (error) {
    console.error('Error submitting form:', error);
    return { success: false, error };
  }
}