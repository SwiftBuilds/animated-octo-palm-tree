import React from 'react';

export function TermsPage() {
  return (
    <main className="pt-20">
      <section className="py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)]">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
            Terms & Conditions
          </h1>
          
          <div className="max-w-4xl mx-auto space-y-8 text-gray-300">
            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">1. Acceptance of Terms</h2>
              <p className="mb-4">
                By accessing and using SwiftBuilds' services, you acknowledge and agree to these terms and conditions. These terms govern your use of our website and services.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">2. Service Terms</h2>
              <ul className="list-disc pl-6 space-y-2">
                <li>All services are provided on an "as is" basis</li>
                <li>Project timelines and deliverables will be specified in individual contracts</li>
                <li>Intellectual property rights remain with the client unless otherwise specified</li>
                <li>Confidentiality of client information is maintained</li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">3. Payment Terms</h2>
              <p className="mb-4">
                Payment schedules and terms will be outlined in project contracts. Standard payment terms include:
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>50% upfront payment for project initiation</li>
                <li>Remaining payment based on project milestones</li>
                <li>Additional charges for scope changes</li>
              </ul>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">4. Intellectual Property</h2>
              <p>
                Upon full payment, clients receive full rights to the delivered software and associated materials, unless specifically excluded in the project contract.
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
              <h2 className="text-2xl font-bold mb-4 text-white">5. Limitation of Liability</h2>
              <p>
                SwiftBuilds shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of our services.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}