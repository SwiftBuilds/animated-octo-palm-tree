import React from 'react';

export function PhoenixIcon({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 240 240"
      className={className}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M120 20c-11.1 0-21.3 6.4-26.2 16.4-10.5 21.5-42.3 86.5-48.9 100-3.1 6.4-3.1 13.8 0 20.2 6.6 13.5 38.4 78.5 48.9 100 4.9 10 15.1 16.4 26.2 16.4s21.3-6.4 26.2-16.4c10.5-21.5 42.3-86.5 48.9-100 3.1-6.4 3.1-13.8 0-20.2-6.6-13.5-38.4-78.5-48.9-100C141.3 26.4 131.1 20 120 20zm0 80c11 0 20 9 20 20s-9 20-20 20-20-9-20-20 9-20 20-20z" />
    </svg>
  );
}