import React from 'react';
import { Mail, Phone, MapPin, Send, Clock, ArrowRight, CheckCircle } from 'lucide-react';

export function ContactPage() {
  return (
    <main className="pt-20">
      <section className="min-h-screen py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)] relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-radial from-blue-600/20 via-blue-900/20 to-transparent" />
          {[...Array(3)].map((_, i) => (
            <div
              key={`wave-${i}`}
              className="absolute inset-0 animate-wave"
              style={{
                background: `radial-gradient(circle at ${50 + (i * 30)}% ${50 + (i * 20)}%, rgba(59,130,246,0.1), transparent 60%)`,
                animationDelay: `${i * 2}s`,
                transform: `scale(${1 + i * 0.2})`,
              }}
            />
          ))}
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white font-display">
              Let's Build Something Amazing Together
            </h1>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto font-sans">
              Ready to transform your ideas into reality? Get in touch with our team of experts.
            </p>
          </div>

          {/* Quick Response Promise */}
          <div className="max-w-6xl mx-auto mb-16">
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-glow" />
              <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 border border-blue-500/20">
                <div className="flex items-center justify-between flex-wrap gap-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-lg">
                      <Clock className="w-8 h-8 text-blue-400" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-white mb-1">Quick Response Guaranteed</h2>
                      <p className="text-blue-200">We reply within 10 hours during business hours</p>
                    </div>
                  </div>
                  <div className="flex gap-6">
                    {['24/7 Support', 'Quick Response', 'Expert Team'].map((item, index) => (
                      <div key={item} className="flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-blue-400" />
                        <span className="text-gray-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Contact Form */}
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-glow" />
              <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 h-full border border-blue-500/20">
                <h2 className="text-2xl font-bold mb-6 text-white">Send us a Message</h2>
                <form className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-blue-200">Name</label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-blue-500/20 focus:border-blue-400 focus:outline-none text-white placeholder-blue-300/50"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-blue-200">Email</label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-blue-500/20 focus:border-blue-400 focus:outline-none text-white placeholder-blue-300/50"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-blue-200">Message</label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-3 rounded-lg bg-white/10 border border-blue-500/20 focus:border-blue-400 focus:outline-none text-white placeholder-blue-300/50"
                      placeholder="Tell us about your project"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 px-6 py-3 rounded-lg font-medium transition-all duration-300 flex items-center justify-center gap-2 group"
                  >
                    <span>Send Message</span>
                    <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </form>
              </div>
            </div>

            {/* Contact Information */}
            <div className="space-y-8">
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
                <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 border border-blue-500/20">
                  <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
                  <div className="space-y-6">
                    <div className="flex items-center gap-4 group/item">
                      <div className="p-3 bg-blue-500/20 rounded-lg group-hover/item:bg-blue-500/30 transition-colors">
                        <Mail className="w-6 h-6 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-blue-300">Email</p>
                        <p className="text-white">Swiftbuilds.co@gmail.com</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 group/item">
                      <div className="p-3 bg-blue-500/20 rounded-lg group-hover/item:bg-blue-500/30 transition-colors">
                        <Phone className="w-6 h-6 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-blue-300">Phone</p>
                        <p className="text-white">+91 9966752470</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 group/item">
                      <div className="p-3 bg-blue-500/20 rounded-lg group-hover/item:bg-blue-500/30 transition-colors">
                        <MapPin className="w-6 h-6 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-blue-300">Location</p>
                        <p className="text-white">Begumpet, Hyderabad, 500016</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
                <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 border border-blue-500/20">
                  <div className="flex items-center gap-4 mb-6">
                    <Clock className="w-6 h-6 text-blue-400" />
                    <h2 className="text-2xl font-bold">Business Hours</h2>
                  </div>
                  <div className="space-y-3 text-gray-300">
                    <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
                    <p>Saturday: 10:00 AM - 2:00 PM</p>
                    <p>Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}