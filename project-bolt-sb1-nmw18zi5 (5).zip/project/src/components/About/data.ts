export const stats = [
  { label: 'Years of Experience', value: '10+' },
  { label: 'Projects Delivered', value: '500+' },
  { label: 'Team Members', value: '100+' },
  { label: 'Client Satisfaction', value: '99%' },
  { label: 'Global Clients', value: '200+' },
  { label: 'Industries Served', value: '15+' }
];

export const values = [
  {
    icon: 'Users',
    title: 'Client-Centric',
    description: "We prioritize our clients success, ensuring solutions that drive real business value."
  },
  {
    icon: 'Target',
    title: 'Innovation',
    description: "Constantly exploring cutting-edge technologies to deliver future-ready solutions."
  },
  {
    icon: 'Award',
    title: 'Excellence',
    description: "Committed to delivering exceptional quality in every project we undertake."
  },
  {
    icon: 'Rocket',
    title: 'Growth',
    description: "Fostering continuous learning and development in our team and solutions."
  }
];

export const milestones = [
  {
    year: '2014',
    title: 'Foundation',
    description: 'Started as a small team of passionate developers in Hyderabad'
  },
  {
    year: '2016',
    title: 'First Major Project',
    description: 'Successfully delivered enterprise solutions for leading Indian corporations'
  },
  {
    year: '2018',
    title: 'International Expansion',
    description: 'Expanded operations to serve clients across Asia and Middle East'
  },
  {
    year: '2020',
    title: 'Innovation Hub',
    description: 'Established AI & ML research center in Bangalore'
  },
  {
    year: '2022',
    title: 'Industry Recognition',
    description: 'Received multiple awards for technological innovation'
  },
  {
    year: '2024',
    title: 'Global Presence',
    description: 'Serving 200+ clients across 15+ countries'
  }
];

export const expertise = [
  {
    icon: 'Code2',
    title: 'Custom Development',
    description: 'Building tailored solutions using cutting-edge technologies'
  },
  {
    icon: 'Globe',
    title: 'Digital Transformation',
    description: 'Helping businesses adapt and thrive in the digital age'
  },
  {
    icon: 'Brain',
    title: 'AI & ML Solutions',
    description: 'Leveraging artificial intelligence for business innovation'
  },
  {
    icon: 'Shield',
    title: 'Cybersecurity',
    description: 'Ensuring robust security for digital assets'
  }
];