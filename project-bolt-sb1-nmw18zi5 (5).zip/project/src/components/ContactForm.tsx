import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { submitContactForm } from '../lib/firebase/services';

interface FormData {
  name: string;
  email: string;
  message: string;
}

export function ContactForm() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      const result = await submitContactForm(formData);
      if (result.success) {
        setStatus('success');
        setFormData({ name: '', email: '', message: '' });
      } else {
        throw new Error('Failed to submit form');
      }
    } catch (error) {
      setStatus('error');
      setErrorMessage('Failed to send message. Please try again later.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2 text-blue-200">Name</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
          className="w-full px-4 py-3 rounded-lg bg-white/10 border border-blue-500/20 focus:border-blue-400 focus:outline-none text-white placeholder-blue-300/50"
          placeholder="Your name"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-2 text-blue-200">Email</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
          className="w-full px-4 py-3 rounded-lg bg-white/10 border border-blue-500/20 focus:border-blue-400 focus:outline-none text-white placeholder-blue-300/50"
          placeholder="your@email.com"
        />
      </div>
      <div>
        <label className="block text-sm font-medium mb-2 text-blue-200">Message</label>
        <textarea
          name="message"
          value={formData.message}
          onChange={handleChange}
          required
          rows={4}
          className="w-full px-4 py-3 rounded-lg bg-white/10 border border-blue-500/20 focus:border-blue-400 focus:outline-none text-white placeholder-blue-300/50"
          placeholder="Tell us about your project"
        ></textarea>
      </div>

      {status === 'error' && (
        <div className="text-red-400 text-sm">{errorMessage}</div>
      )}

      {status === 'success' && (
        <div className="text-green-400 text-sm">Message sent successfully!</div>
      )}

      <button
        type="submit"
        disabled={status === 'submitting'}
        className="w-full bg-gradient-to-r from-blue-500 to-blue-700 hover:from-blue-600 hover:to-blue-800 px-6 py-3 rounded-lg font-medium transition-all duration-300 flex items-center justify-center gap-2 group disabled:opacity-50"
      >
        <span>{status === 'submitting' ? 'Sending...' : 'Send Message'}</span>
        <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
      </button>
    </form>
  );
}