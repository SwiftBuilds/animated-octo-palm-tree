import { Smartphone, Globe, Palette, Brain, Cloud, Shield, Database, Code, Bot } from 'lucide-react';

export const servicesData = [
  {
    title: 'App Development',
    description: 'Native and cross-platform mobile applications built for performance.',
    Icon: Smartphone,
    features: ['iOS & Android Development', 'React Native', 'Flutter', 'Performance Optimization'],
  },
  {
    title: 'Web Development',
    description: 'Modern web applications with cutting-edge technologies.',
    Icon: Globe,
    features: ['Full-Stack Development', 'Progressive Web Apps', 'E-commerce Solutions', 'API Integration'],
  },
  {
    title: 'UI/UX Design',
    description: 'User-centric design that delivers exceptional experiences.',
    Icon: Palette,
    features: ['User Research', 'Wireframing', 'Prototyping', 'Design Systems'],
  },
  {
    title: 'Software Consulting',
    description: 'Strategic technology guidance for business growth.',
    Icon: Brain,
    features: ['Technology Strategy', 'Architecture Design', 'Process Optimization', 'Team Augmentation'],
  },
  {
    title: 'Cloud Solutions',
    description: 'Scalable cloud infrastructure and migration services.',
    Icon: Cloud,
    features: ['AWS & Azure', 'Cloud Migration', 'DevOps', 'Serverless Architecture'],
  },
  {
    title: 'Cybersecurity',
    description: 'Comprehensive security solutions for digital assets.',
    Icon: Shield,
    features: ['Security Audits', 'Penetration Testing', 'Compliance', 'Security Training'],
  },
  {
    title: 'Data Engineering',
    description: 'Build robust data pipelines and analytics solutions.',
    Icon: Database,
    features: ['Data Warehousing', 'ETL Pipelines', 'Big Data', 'Analytics'],
  },
  {
    title: 'AI & ML Solutions',
    description: 'Intelligent solutions powered by machine learning.',
    Icon: Bot,
    features: ['Predictive Analytics', 'Computer Vision', 'NLP', 'Custom ML Models'],
  },
  {
    title: 'Legacy Modernization',
    description: 'Transform legacy systems into modern applications.',
    Icon: Code,
    features: ['System Analysis', 'Code Refactoring', 'Platform Migration', 'Tech Stack Upgrade'],
  },
];