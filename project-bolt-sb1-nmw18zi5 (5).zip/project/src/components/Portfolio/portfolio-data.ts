import { Code, Globe, Smartphone, ShoppingCart, Brain, Shield, Database } from 'lucide-react';

export const portfolioData = [
  {
    title: 'E-Commerce Platform',
    description: 'Full-featured marketplace with real-time inventory and AI-powered recommendations',
    category: 'Web Development',
    tech: ['React', 'Node.js', 'MongoDB', 'AWS'],
    Icon: ShoppingCart
  },
  {
    title: 'Healthcare App',
    description: 'Telemedicine platform with secure video consultations and medical records management',
    category: 'Mobile Development',
    tech: ['React Native', 'Firebase', 'HIPAA Compliance'],
    Icon: Smartphone
  },
  {
    title: 'FinTech Dashboard',
    description: 'Real-time financial analytics with ML-powered predictions',
    category: 'Web Development',
    tech: ['Vue.js', 'Python', 'TensorFlow'],
    Icon: Brain
  },
  {
    title: 'Security Platform',
    description: 'Enterprise-grade security monitoring and threat detection system',
    category: 'Cybersecurity',
    tech: ['Go', 'Elasticsearch', 'Kubernetes'],
    Icon: Shield
  },
  {
    title: 'Data Pipeline',
    description: 'Scalable ETL pipeline processing millions of records daily',
    category: 'Data Engineering',
    tech: ['Apache Spark', 'AWS', 'Python'],
    Icon: Database
  },
  {
    title: 'IoT Platform',
    description: 'Real-time monitoring system for industrial IoT devices',
    category: 'IoT Development',
    tech: ['MQTT', 'Node.js', 'InfluxDB'],
    Icon: Globe
  },
  {
    title: 'CMS Platform',
    description: 'Headless CMS with API-first architecture',
    category: 'Web Development',
    tech: ['Next.js', 'GraphQL', 'PostgreSQL'],
    Icon: Code
  }
];