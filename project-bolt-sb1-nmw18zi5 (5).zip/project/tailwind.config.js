/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#14134f',
        secondary: 'rgba(20,19,79,255)',
        accent: '#3b82f6',
      },
      fontFamily: {
        sans: ['Outfit', 'system-ui', 'sans-serif'],
        display: ['Space Grotesk', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display-1': ['4.5rem', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'display-2': ['3.75rem', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'heading-1': ['3rem', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'heading-2': ['2.25rem', { lineHeight: '1.3' }],
        'heading-3': ['1.875rem', { lineHeight: '1.4' }],
        'body-large': ['1.25rem', { lineHeight: '1.6' }],
        'body': ['1rem', { lineHeight: '1.6' }],
        'small': ['0.875rem', { lineHeight: '1.5' }],
      },
      animation: {
        'liquid-wave': 'liquid-wave 12s linear infinite',
        'float': 'float 20s ease-in-out infinite',
        'pulse': 'pulse 3s ease-in-out infinite',
        'fadeIn': 'fadeIn 0.3s ease-in-out',
        'glow': 'glow 2s ease-in-out infinite',
      },
      keyframes: {
        'liquid-wave': {
          '0%': { transform: 'translateX(-100%) translateZ(0) scaleY(1)' },
          '50%': { transform: 'translateX(25%) translateZ(0) scaleY(0.8)' },
          '100%': { transform: 'translateX(100%) translateZ(0) scaleY(1)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
          '50%': { transform: 'translateY(-20px) rotate(10deg)' },
        },
        'pulse': {
          '0%, 100%': { opacity: 0.6, transform: 'scale(1)' },
          '50%': { opacity: 0.8, transform: 'scale(1.1)' },
        },
        'fadeIn': {
          '0%': { opacity: 0, transform: 'translateY(10px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        'glow': {
          '0%, 100%': { filter: 'brightness(1)' },
          '50%': { filter: 'brightness(1.2)' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
    },
  },
  plugins: [],
};