import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ServiceDetailProps {
  title: string;
  description: string;
  Icon: LucideIcon;
  features: string[];
}

export function ServiceDetail({ title, description, Icon, features }: ServiceDetailProps) {
  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
      <div className="flex items-start gap-6">
        <Icon className="w-16 h-16 text-purple-400 flex-shrink-0" />
        <div>
          <h2 className="text-3xl font-bold mb-4">{title}</h2>
          <p className="text-xl text-gray-300 mb-8">{description}</p>
          
          <h3 className="text-xl font-semibold mb-4">Key Features</h3>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((feature) => (
              <li key={feature} className="flex items-center gap-2">
                <span className="w-2 h-2 bg-purple-400 rounded-full" />
                <span className="text-gray-300">{feature}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}