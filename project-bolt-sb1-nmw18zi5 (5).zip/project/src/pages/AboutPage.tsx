import React from 'react';
import { Stats } from '../components/About/Stats';
import { Story } from '../components/About/Story';
import { Values } from '../components/About/Values';

export function AboutPage() {
  return (
    <main className="pt-20">
      <section className="py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)]">
        <div className="container mx-auto px-6">
          {/* Hero Section */}
          <div className="text-center mb-20">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
              Innovating the Future of Technology
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              SwiftBuilds is a leading software development company committed to delivering innovative solutions that empower businesses to thrive in the digital age.
            </p>
          </div>

          <Stats />
          <Story />
          <Values />
        </div>
      </section>
    </main>
  );
}