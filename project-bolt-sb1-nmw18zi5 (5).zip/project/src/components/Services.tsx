import React from 'react';
import { Smartphone, Globe, Palette, Brain, Cloud, Shield, Database, Code, Bot } from 'lucide-react';
import { ServiceCard } from './ServiceCard';

export function Services() {
  const services = [
    {
      title: 'App Development',
      description: 'Native and cross-platform mobile applications built for performance.',
      Icon: Smartphone,
      features: ['iOS & Android Development', 'React Native', 'Flutter', 'Performance Optimization'],
    },
    {
      title: 'Web Development',
      description: 'Modern web applications with cutting-edge technologies.',
      Icon: Globe,
      features: ['Full-Stack Development', 'Progressive Web Apps', 'E-commerce Solutions', 'API Integration'],
    },
    {
      title: 'UI/UX Design',
      description: 'User-centric design that delivers exceptional experiences.',
      Icon: Palette,
      features: ['User Research', 'Wireframing', 'Prototyping', 'Design Systems'],
    },
    {
      title: 'Software Consulting',
      description: 'Strategic technology guidance for business growth.',
      Icon: Brain,
      features: ['Technology Strategy', 'Architecture Design', 'Process Optimization', 'Team Augmentation'],
    },
    {
      title: 'Cloud Solutions',
      description: 'Scalable cloud infrastructure and migration services.',
      Icon: Cloud,
      features: ['AWS & Azure', 'Cloud Migration', 'DevOps', 'Serverless Architecture'],
    },
    {
      title: 'Cybersecurity',
      description: 'Comprehensive security solutions for digital assets.',
      Icon: Shield,
      features: ['Security Audits', 'Penetration Testing', 'Compliance', 'Security Training'],
    },
    {
      title: 'Data Engineering',
      description: 'Build robust data pipelines and analytics solutions.',
      Icon: Database,
      features: ['Data Warehousing', 'ETL Pipelines', 'Big Data', 'Analytics'],
    },
    {
      title: 'AI & ML Solutions',
      description: 'Intelligent solutions powered by machine learning.',
      Icon: Bot,
      features: ['Predictive Analytics', 'Computer Vision', 'NLP', 'Custom ML Models'],
    },
    {
      title: 'Legacy Modernization',
      description: 'Transform legacy systems into modern applications.',
      Icon: Code,
      features: ['System Analysis', 'Code Refactoring', 'Platform Migration', 'Tech Stack Upgrade'],
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)] text-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Our Services</h2>
          <p className="text-xl text-gray-300">
            Comprehensive solutions for your digital transformation journey
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <ServiceCard key={service.title} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
}