import React from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

export interface FAQItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}

export function FAQItem({ question, answer, isOpen, onClick }: FAQItemProps) {
  return (
    <div className="border-b border-white/10">
      <button
        className="w-full py-4 flex items-center justify-between text-left group"
        onClick={onClick}
      >
        <span className="text-lg font-medium group-hover:text-accent transition-colors">
          {question}
        </span>
        {isOpen ? (
          <ChevronUp className="w-5 h-5 text-accent" />
        ) : (
          <ChevronDown className="w-5 h-5 text-accent" />
        )}
      </button>
      {isOpen && (
        <div className="pb-4 text-gray-300 animate-fadeIn">
          {answer}
        </div>
      )}
    </div>
  );
}