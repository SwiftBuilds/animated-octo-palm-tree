import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAkLlTqmesWAe6HKB57GgrZIIRKRjLWXlU",
  authDomain: "swift-builds.firebaseapp.com",
  projectId: "swift-builds",
  storageBucket: "swift-builds.firebasestorage.app",
  messagingSenderId: "877292825473",
  appId: "1:877292825473:web:41268d7fca123ca9831680",
  measurementId: "G-9BB6E78450"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);