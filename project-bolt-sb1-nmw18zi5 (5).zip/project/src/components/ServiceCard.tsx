import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Link } from './Link';

interface ServiceCardProps {
  title: string;
  description: string;
  Icon: LucideIcon;
  features: string[];
}

export function ServiceCard({ title, description, Icon, features }: ServiceCardProps) {
  return (
    <Link href={`/services#${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-6 hover:transform hover:scale-105 transition-all duration-300 border border-transparent hover:border-purple-400 group">
        <div className="relative">
          <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg blur opacity-25 group-hover:opacity-75 transition duration-1000 group-hover:duration-200" />
          <div className="relative">
            <Icon className="w-12 h-12 text-purple-500 mb-4 group-hover:text-purple-400 transition-colors" />
            <h3 className="text-xl font-bold mb-2 group-hover:text-purple-400 transition-colors">{title}</h3>
            <p className="text-gray-300 mb-4">{description}</p>
            <ul className="space-y-2">
              {features.map((feature, index) => (
                <li key={index} className="text-sm text-gray-400 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-purple-500 rounded-full" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Link>
  );
}