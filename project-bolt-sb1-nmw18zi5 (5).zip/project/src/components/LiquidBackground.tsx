import React from 'react';

export function LiquidBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Liquid waves */}
      <div className="absolute inset-0">
        {[...Array(3)].map((_, i) => (
          <div
            key={`wave-${i}`}
            className="absolute w-[200%] h-full"
            style={{
              top: `${i * 20}%`,
              animation: `liquid-wave ${12 + i * 4}s linear infinite`,
              background: `radial-gradient(circle at 50% 50%, rgba(59,130,246,${0.03 + i * 0.02}), transparent 70%)`,
              transform: `translateZ(0) rotate(${i * 5}deg)`,
            }}
          />
        ))}
      </div>

      {/* Floating orbs */}
      {[...Array(15)].map((_, i) => (
        <div
          key={`orb-${i}`}
          className="absolute rounded-full mix-blend-screen"
          style={{
            width: `${Math.random() * 200 + 50}px`,
            height: `${Math.random() * 200 + 50}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: `radial-gradient(circle at center, rgba(59,130,246,0.15), transparent)`,
            animation: `float ${Math.random() * 10 + 15}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`,
          }}
        />
      ))}

      {/* Glowing particles */}
      {[...Array(30)].map((_, i) => (
        <div
          key={`particle-${i}`}
          className="absolute rounded-full"
          style={{
            width: `${Math.random() * 4 + 2}px`,
            height: `${Math.random() * 4 + 2}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: 'rgba(59,130,246,0.3)',
            animation: `pulse ${Math.random() * 4 + 2}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 2}s`,
          }}
        />
      ))}
    </div>
  );
}