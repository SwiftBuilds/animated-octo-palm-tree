import React, { useState } from 'react';
import { Code2, Globe, Smartphone, ShoppingCart, Brain, Shield, Database, Cloud, Palette } from 'lucide-react';

const categories = ["All", "Web Development", "Mobile Development", "AI & ML", "Cloud Solutions", "UI/UX Design"];

const projects = [
  {
    title: 'E-Commerce Platform',
    description: 'Full-featured marketplace with real-time inventory and AI-powered recommendations',
    image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'Web Development',
    tech: ['React', 'Node.js', 'MongoDB', 'AWS'],
    icon: ShoppingCart,
    client: 'RetailTech India'
  },
  {
    title: 'Healthcare App',
    description: 'Telemedicine platform with secure video consultations and medical records',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'Mobile Development',
    tech: ['React Native', 'Firebase', 'HIPAA Compliance'],
    icon: Smartphone,
    client: 'MedCare Solutions'
  },
  {
    title: 'AI-Powered Analytics',
    description: 'Real-time financial analytics and ML-powered predictions platform',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'AI & ML',
    tech: ['Python', 'TensorFlow', 'Vue.js', 'AWS'],
    icon: Brain,
    client: 'FinTech Global'
  },
  {
    title: 'Cloud Migration',
    description: 'Enterprise-scale cloud migration and infrastructure modernization',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'Cloud Solutions',
    tech: ['AWS', 'Kubernetes', 'Terraform', 'Docker'],
    icon: Cloud,
    client: 'TechCorp India'
  },
  {
    title: 'Supply Chain Platform',
    description: 'Blockchain-based supply chain management system',
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'Web Development',
    tech: ['Hyperledger', 'Node.js', 'React', 'MongoDB'],
    icon: Database,
    client: 'LogiChain Systems'
  },
  {
    title: 'Banking App Redesign',
    description: 'Complete UX/UI overhaul of a major banking application',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'UI/UX Design',
    tech: ['Figma', 'React Native', 'Swift', 'Kotlin'],
    icon: Palette,
    client: 'National Bank'
  },
  {
    title: 'Smart City Dashboard',
    description: 'IoT-based city infrastructure monitoring system',
    image: 'https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'Web Development',
    tech: ['React', 'Node.js', 'IoT', 'GraphQL'],
    icon: Globe,
    client: 'SmartCity Corp'
  },
  {
    title: 'EdTech Platform',
    description: 'AI-powered personalized learning platform',
    image: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'AI & ML',
    tech: ['Python', 'React', 'TensorFlow', 'AWS'],
    icon: Code2,
    client: 'EduTech Solutions'
  },
  {
    title: 'Cybersecurity Suite',
    description: 'Enterprise security monitoring and threat detection',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    category: 'Web Development',
    tech: ['Go', 'React', 'Elasticsearch', 'AWS'],
    icon: Shield,
    client: 'SecureNet'
  }
];

export function PortfolioPage() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const filteredProjects = projects.filter(
    project => selectedCategory === "All" || project.category === selectedCategory
  );

  return (
    <main className="pt-20">
      <section className="py-20 bg-gradient-to-br from-[#14134f] to-[rgba(20,19,79,255)]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
              Our Portfolio
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Discover how we've helped businesses transform their digital presence with innovative solutions
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full transition-all duration-300 ${
                  selectedCategory === category
                    ? 'bg-blue-500 text-white'
                    : 'bg-white/5 text-gray-300 hover:bg-white/10'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => (
              <div
                key={project.title}
                className="group relative"
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-glow" />
                
                <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl overflow-hidden">
                  <div className="relative h-64">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#14134f] to-transparent opacity-90" />
                  </div>

                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-2">
                      <project.icon className="w-5 h-5 text-blue-400" />
                      <span className="text-sm text-blue-400">{project.category}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-2 text-white group-hover:text-blue-300 transition-colors">
                      {project.title}
                    </h3>
                    
                    <p className="text-gray-300 mb-4">{project.description}</p>
                    
                    <div className="space-y-3">
                      <div className="flex flex-wrap gap-2">
                        {project.tech.map((tech) => (
                          <span
                            key={tech}
                            className="text-xs px-2 py-1 rounded-full bg-blue-500/20 text-blue-300"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                      <p className="text-sm text-blue-400">Client: {project.client}</p>
                    </div>

                    <div className={`absolute bottom-4 right-4 transform transition-all duration-300 ${
                      hoveredIndex === index ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                    }`}>
                      <button className="flex items-center gap-2 text-blue-400 hover:text-blue-300">
                        View Details
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}