import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  Icon: LucideIcon;
  features: string[];
}

export function ServiceCard({ title, description, Icon, features }: ServiceCardProps) {
  return (
    <div
      id={title.toLowerCase().replace(/\s+/g, '-')}
      className="group relative"
    >
      <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
      
      <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 h-full border border-blue-500/20 transition-all duration-500 group-hover:translate-y-[-4px]">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 bg-gradient-to-br from-blue-500/20 to-transparent rounded-lg">
            <Icon className="w-8 h-8 text-blue-400 group-hover:text-blue-300 transition-colors" />
          </div>
          <h3 className="text-2xl font-bold text-white group-hover:text-blue-200 transition-colors">
            {title}
          </h3>
        </div>
        
        <p className="text-gray-300 mb-6">{description}</p>
        
        <div className="space-y-2">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-2 text-sm text-gray-400 group-hover:text-gray-300">
              <span className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
              {feature}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}