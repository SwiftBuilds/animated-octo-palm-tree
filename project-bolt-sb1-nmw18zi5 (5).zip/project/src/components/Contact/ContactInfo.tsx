import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

export function ContactInfo() {
  return (
    <div className="space-y-8">
      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <Mail className="w-6 h-6 text-purple-400" />
            <span>Swiftbuilds.co@gmail.com</span>
          </div>
          <div className="flex items-center gap-4">
            <Phone className="w-6 h-6 text-purple-400" />
            <span>+91 9966752470</span>
          </div>
          <div className="flex items-center gap-4">
            <MapPin className="w-6 h-6 text-purple-400" />
            <span>Begumpet, Hyderabad, 500016</span>
          </div>
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-lg rounded-xl p-8">
        <h2 className="text-2xl font-bold mb-6">Office Hours</h2>
        <div className="space-y-2">
          <p>Monday - Friday: 9:00 AM - 6:00 PM</p>
          <p>Saturday: 10:00 AM - 2:00 PM</p>
          <p>Sunday: Closed</p>
        </div>
      </div>
    </div>
  );
}