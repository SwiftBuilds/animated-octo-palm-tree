import React from 'react';
import { stats } from './data';

export function Stats() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 mb-20">
      {stats.map((stat) => (
        <div key={stat.label} className="text-center group">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-700 blur-sm opacity-0 group-hover:opacity-75 transition-opacity" />
            <div className="relative">
              <div className="text-4xl font-bold text-blue-400 mb-2">{stat.value}</div>
              <div className="text-gray-300">{stat.label}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}