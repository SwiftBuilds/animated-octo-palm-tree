import React from 'react';
import { Facebook, Linkedin, Twitter, Mail, MapPin, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="bg-gradient-to-b from-primary via-secondary to-primary text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">SwiftBuilds</h3>
            <div className="space-y-2">
              <p className="flex items-center gap-2 text-gray-300 hover:text-accent transition-colors">
                <Mail size={16} />
                Swiftbuilds.co@gmail.com
              </p>
              <p className="flex items-center gap-2 text-gray-300 hover:text-accent transition-colors">
                <MapPin size={16} />
                Begumpet, Hyderabad, 500016
              </p>
              <p className="flex items-center gap-2 text-gray-300 hover:text-accent transition-colors">
                <Phone size={16} />
                +91 9966752470
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/privacy" className="text-gray-300 hover:text-accent transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-gray-300 hover:text-accent transition-colors">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link to="/partners" className="text-gray-300 hover:text-accent transition-colors">
                  Trusted Partners
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services#app-development" className="text-gray-300 hover:text-accent transition-colors">
                  App Development
                </Link>
              </li>
              <li>
                <Link to="/services#web-development" className="text-gray-300 hover:text-accent transition-colors">
                  Web Development
                </Link>
              </li>
              <li>
                <Link to="/services#ui-ux-design" className="text-gray-300 hover:text-accent transition-colors">
                  UI/UX Design
                </Link>
              </li>
              <li>
                <Link to="/services#consulting" className="text-gray-300 hover:text-accent transition-colors">
                  Software Consulting
                </Link>
              </li>
              <li>
                <Link to="/services#cloud" className="text-gray-300 hover:text-accent transition-colors">
                  Cloud Solutions
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4">Connect With Us</h3>
            <div className="flex space-x-4">
              <a
                href="https://facebook.com"
                className="text-gray-300 hover:text-accent transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Facebook size={24} />
              </a>
              <a
                href="https://linkedin.com"
                className="text-gray-300 hover:text-accent transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Linkedin size={24} />
              </a>
              <a
                href="https://twitter.com"
                className="text-gray-300 hover:text-accent transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Twitter size={24} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8 text-center text-gray-300">
          <p>&copy; {new Date().getFullYear()} SwiftBuilds. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}