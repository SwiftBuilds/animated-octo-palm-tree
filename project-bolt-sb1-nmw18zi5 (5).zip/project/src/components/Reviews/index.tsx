import React from 'react';
import { Star } from 'lucide-react';

const reviews = [
  {
    name: "Rajesh Kumar",
    role: "CTO, TechVeda Solutions",
    content: "SwiftBuilds completely transformed our digital presence. Their expertise in cloud solutions and AI integration gave us a competitive edge in the market. The team's dedication to excellence is unmatched.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  },
  {
    name: "Priya Sharma",
    role: "Founder, InnovateIndia",
    content: "The quality and commitment to innovation by the SwiftBuilds team is exceptional. They delivered our project ahead of schedule and exceeded our expectations in every aspect.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  },
  {
    name: "Amit Patel",
    role: "CEO, Digital Dynamics",
    content: "Working with SwiftBuilds was a game-changer for our startup. Their agile approach and technical expertise are unparalleled. They truly understand the Indian market's unique needs.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  },
  {
    name: "Neha Reddy",
    role: "Product Head, FutureTech",
    content: "As an Indian company, we take pride in SwiftBuilds' services. Their team understood our vision and turned it into reality with remarkable precision and innovation.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  },
  {
    name: "Vikram Singh",
    role: "Director, CloudTech India",
    content: "SwiftBuilds' cloud migration expertise helped us modernize our entire infrastructure. Their team's technical prowess and project management skills are outstanding.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  },
  {
    name: "Ananya Krishnan",
    role: "CIO, FinnovateX",
    content: "The AI solutions developed by SwiftBuilds revolutionized our financial services. Their understanding of cutting-edge technology and business needs is impressive.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80"
  }
];

export function Reviews() {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-radial from-blue-600/20 via-blue-900/20 to-transparent" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-blue-400 to-white">
            Client Testimonials
          </h2>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto">
            Trusted by Leading Indian Businesses
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-glow" />
              
              <div className="relative bg-[#14134f]/50 backdrop-blur-xl rounded-xl p-8 h-full border border-blue-500/20">
                <div className="flex items-center gap-4 mb-6">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-blue-500"
                  />
                  <div>
                    <h3 className="font-bold text-white text-lg">{review.name}</h3>
                    <p className="text-blue-300 text-sm">{review.role}</p>
                    <div className="flex gap-1 mt-1">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-blue-400 text-blue-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-300 text-lg leading-relaxed">{review.content}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}