import React from 'react';

interface GradientProps {
  children: React.ReactNode;
  className?: string;
}

export function Gradient({ children, className = '' }: GradientProps) {
  return (
    <div className={`bg-gradient-to-br from-primary to-secondary ${className}`}>
      {children}
    </div>
  );
}